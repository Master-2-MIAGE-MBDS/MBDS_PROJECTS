package com.mbds.grails

import grails.gorm.services.Service
import grails.web.servlet.mvc.GrailsParameterMap

import javax.servlet.http.HttpServletRequest

@Service(User)
interface UserService {

    //uploadImage(contact, request)
    User get(Serializable id)

    List<User> list(Map args)

    Long count()

    void delete(Serializable id)

    User save(User user)

}
